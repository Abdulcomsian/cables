<!--Filters Start-->
<div class="w-3/12 px-4 hidden lg:block">
    <div class="flex justify-between">
      <h2 class="font-bold text-xl text-[#000038]">Filter results</h2>
      <button class="px-2 py-1 text-white bg-gray-500 rounded">
        Reset
      </button>
    </div>

    <!--Speed Filters Start-->
    <div class="mb-4">
      <h2 class="font-bold text-xl text-[#000038] mb-3">Speed</h2>
      <div class="grid grid-cols-2 gap-2">
        <button
          class="bg-white border border-gray-400 w-full py-1 rounded transition-shadow duration-500 hover:inner-shadow"
        >
          1-60MB
        </button>
        <button
          class="bg-white border border-gray-400 w-full py-1 rounded transition-shadow duration-500 hover:inner-shadow"
        >
          60-100MB
        </button>
        <button
          class="bg-white border border-gray-400 w-full py-1 rounded transition-shadow duration-500 hover:inner-shadow"
        >
          100-500MB
        </button>
        <button
          class="bg-white border border-gray-400 w-full py-1 rounded transition-shadow duration-500 hover:inner-shadow"
        >
          500-1GB
        </button>
        <button
          class="bg-white border border-gray-400 w-full py-1 rounded transition-shadow duration-500 hover:inner-shadow"
        >
          1GB+
        </button>
      </div>
    </div>
    <!--Speed Filters End-->

    <!--Tv Channels Filters Start-->
    <div class="mb-4">
      <h2 class="font-bold text-xl text-[#000038] mb-3">TV channels</h2>

      <div class="grid grid-cols-2 gap-2">
        <button
          class="bg-white border flex justify-center border-gray-400 w-full py-1 rounded transition-shadow duration-500 hover:inner-shadow"
        >
          <div class="w-20">
            <img src="./images/Tnt-sports.webp" alt="" class="w-full" />
          </div>
        </button>
        <button
          class="bg-white border flex justify-center border-gray-400 w-full py-1 rounded transition-shadow duration-500 hover:inner-shadow"
        >
          <div class="w-20">
            <img src="./images/Tnt-sports.webp" alt="" class="w-full" />
          </div>
        </button>
        <button
          class="bg-white border flex justify-center border-gray-400 w-full py-1 rounded transition-shadow duration-500 hover:inner-shadow"
        >
          <div class="w-20">
            <img src="./images/Tnt-sports.webp" alt="" class="w-full" />
          </div>
        </button>
        <button
          class="bg-white border flex justify-center border-gray-400 w-full py-1 rounded transition-shadow duration-500 hover:inner-shadow"
        >
          <div class="w-20">
            <img src="./images/Tnt-sports.webp" alt="" class="w-full" />
          </div>
        </button>
        <button
          class="bg-white border flex justify-center border-gray-400 w-full py-1 rounded transition-shadow duration-500 hover:inner-shadow"
        >
          <div class="w-20">
            <img src="./images/Tnt-sports.webp" alt="" class="w-full" />
          </div>
        </button>
        <button
          class="bg-white border flex justify-center border-gray-400 w-full py-1 rounded transition-shadow duration-500 hover:inner-shadow"
        >
          <div class="w-20">
            <img src="./images/Tnt-sports.webp" alt="" class="w-full" />
          </div>
        </button>
      </div>
    </div>
    <!--Tv Channels Filters End-->

    <!--Package Filters Start-->
    <div class="mb-4">
      <h2 class="font-bold text-xl text-[#000038] mb-3">Package</h2>
      <div class="grid grid-cols-1 gap-2">
        <button
          class="bg-white border text-left px-4 border-gray-400 w-full py-1 rounded transition-shadow duration-500 hover:inner-shadow"
        >
          Broadband + TV
        </button>
        <button
          class="bg-white border text-left px-4 border-gray-400 w-full py-1 rounded transition-shadow duration-500 hover:inner-shadow"
        >
          Broadband + calls
        </button>
        <button
          class="bg-white border text-left px-4 border-gray-400 w-full py-1 rounded transition-shadow duration-500 hover:inner-shadow"
        >
          Broadband only
        </button>
      </div>
    </div>
    <!--Package Filters End-->
    <!--Monthly Cost Filters Start-->
    <div class="mb-4">
      <h2 class="font-bold text-xl text-[#000038] mb-3">Monthly cost</h2>
      <div class="grid grid-cols-2 gap-2">
        <button
          class="bg-white border border-gray-400 w-full py-1 rounded transition-shadow duration-500 hover:inner-shadow"
        >
          $0-$25
        </button>
        <button
          class="bg-white border border-gray-400 w-full py-1 rounded transition-shadow duration-500 hover:inner-shadow"
        >
          $0-$25
        </button>
        <button
          class="bg-white border border-gray-400 w-full py-1 rounded transition-shadow duration-500 hover:inner-shadow"
        >
          $0-$25
        </button>

        <button
          class="bg-white border border-gray-400 w-full py-1 rounded transition-shadow duration-500 hover:inner-shadow"
        >
          $0-$25
        </button>
      </div>
    </div>
    <!--Monthly Cost Filters End-->

    <!--Offers Filters Start-->
    <div class="mb-4">
      <h2 class="font-bold text-xl text-[#000038] mb-3">Offers</h2>
      <div class="grid grid-cols-1 gap-2">
        <button
          class="bg-white border px-4 text-left border-gray-400 w-full py-1 rounded transition-shadow duration-500 hover:inner-shadow"
        >
          Deals with no upfront cost
        </button>
        <button
          class="bg-white border px-4 text-left border-gray-400 w-full py-1 rounded transition-shadow duration-500 hover:inner-shadow"
        >
          Deals with rewards and offers
        </button>
      </div>
    </div>
    <!--Offers Filters End-->

    <!--Providers Filters Start-->
    <div class="mb-4">
      <h2 class="font-bold text-xl text-[#000038] mb-3">Providers</h2>

      <div class="grid grid-cols-3 gap-2">
        <button
          class="bg-white border flex justify-center border-gray-400 w-full py-1 rounded transition-shadow duration-500 hover:inner-shadow"
        >
          <div class="w-20">
            <img src="./images/sky.webp" alt="" class="w-full" />
          </div>
        </button>
        <button
          class="bg-white border flex justify-center border-gray-400 w-full py-1 rounded transition-shadow duration-500 hover:inner-shadow"
        >
          <div class="w-20">
            <img src="./images/sky.webp" alt="" class="w-full" />
          </div>
        </button>
        <button
          class="bg-white border flex justify-center border-gray-400 w-full py-1 rounded transition-shadow duration-500 hover:inner-shadow"
        >
          <div class="w-20">
            <img src="./images/sky.webp" alt="" class="w-full" />
          </div>
        </button>
        <button
          class="bg-white border flex justify-center border-gray-400 w-full py-1 rounded transition-shadow duration-500 hover:inner-shadow"
        >
          <div class="w-20">
            <img src="./images/sky.webp" alt="" class="w-full" />
          </div>
        </button>
        <button
          class="bg-white border flex justify-center border-gray-400 w-full py-1 rounded transition-shadow duration-500 hover:inner-shadow"
        >
          <div class="w-20">
            <img src="./images/sky.webp" alt="" class="w-full" />
          </div>
        </button>
        <button
          class="bg-white border flex justify-center border-gray-400 w-full py-1 rounded transition-shadow duration-500 hover:inner-shadow"
        >
          <div class="w-20">
            <img src="./images/sky.webp" alt="" class="w-full" />
          </div>
        </button>
      </div>
    </div>
    <!--Providers Filters End-->

    <!--Contract length Filters Start-->
    <div class="mb-4">
      <h2 class="font-bold text-xl text-[#000038] mb-3">
        Contract length
      </h2>
      <div class="grid grid-cols-2 gap-2">
        <button
          class="bg-white border border-gray-400 w-full py-1 rounded transition-shadow duration-500 hover:inner-shadow"
        >
          1 month
        </button>
        <button
          class="bg-white border border-gray-400 w-full py-1 rounded transition-shadow duration-500 hover:inner-shadow"
        >
          12 month
        </button>
        <button
          class="bg-white border border-gray-400 w-full py-1 rounded transition-shadow duration-500 hover:inner-shadow"
        >
          18 month
        </button>
        <button
          class="bg-white border border-gray-400 w-full py-1 rounded transition-shadow duration-500 hover:inner-shadow"
        >
          18+ month
        </button>
      </div>
    </div>
    <!--Contract length Filters End-->

    <!--Phone & line Filters Start-->
    <div class="mb-4">
      <h2 class="font-bold text-xl text-[#000038] mb-3">Phone & line</h2>
      <div class="grid grid-cols-1 gap-2">
        <button
          class="bg-white border px-4 text-left border-gray-400 w-full py-1 rounded transition-shadow duration-500 hover:inner-shadow"
        >
          Anytime calls
        </button>
        <button
          class="bg-white border px-4 text-left border-gray-400 w-full py-1 rounded transition-shadow duration-500 hover:inner-shadow"
        >
          Evening & weekend calls
        </button>
        <button
          class="bg-white border px-4 text-left border-gray-400 w-full py-1 rounded transition-shadow duration-500 hover:inner-shadow"
        >
          Weekend calls
        </button>
        <button
          class="bg-white border px-4 text-left border-gray-400 w-full py-1 rounded transition-shadow duration-500 hover:inner-shadow"
        >
          Pay as you go calls
        </button>
        <button
          class="bg-white border px-4 text-left border-gray-400 w-full py-1 rounded transition-shadow duration-500 hover:inner-shadow"
        >
          No phone line
        </button>
      </div>
    </div>
    <!--Phone & line Filters End-->
  </div>
    <!--Filters  End-->