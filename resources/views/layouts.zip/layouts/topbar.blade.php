    <!--Navbar Section Start -->
    <nav class="bg-white border-gray-200 dark:bg-gray-900">
        <div
          class="max-w-screen-xl flex flex-wrap items-center justify-between mx-auto p-4"
        >
          <a class="flex items-end">
            <span class="text-2xl font-bold whitespace-nowrap">Cable</span>
            <span class="text-gray-500 text-lg font-semibold">.co.uk</span>
          </a>
          <button
            data-collapse-toggle="navbar-default"
            type="button"
            class="inline-flex items-center p-2 w-10 h-10 justify-center text-sm text-gray-500 rounded-lg md:hidden hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200 dark:text-gray-400 dark:hover:bg-gray-700 dark:focus:ring-gray-600"
            aria-controls="navbar-default"
            aria-expanded="false"
          >
            <span class="sr-only">Open main menu</span>
            <svg
              class="w-5 h-5"
              aria-hidden="true"
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 17 14"
            >
              <path
                stroke="currentColor"
                stroke-linecap="round"
                stroke-linejoin="round"
                stroke-width="2"
                d="M1 1h15M1 7h15M1 13h15"
              />
            </svg>
          </button>
          <div class="hidden w-full md:block md:w-auto" id="navbar-default">
            <ul
              class="font-medium flex flex-col p-4 md:p-0 mt-4 border border-gray-100 rounded-lg bg-gray-50 md:flex-row md:space-x-8 rtl:space-x-reverse md:mt-0 md:border-0 md:bg-white dark:bg-gray-800 md:dark:bg-gray-900 dark:border-gray-700"
            >
              <li>
                <a
                  href="/broadband"
                  class="block py-2 px-3 text-lg font-medium text-primary rounded md:bg-transparent md:text-primary md:p-0"
                  aria-current="page"
                >
                  Broadband</a
                >
              </li>
              <li>
                <a
                  href="#"
                  class="block py-2 px-3 text-lg font-medium text-primary rounded md:bg-transparent md:text-primary md:p-0"
                  >Tv</a
                >
              </li>
              <li>
                <a
                  href="#"
                  class="block py-2 px-3 text-lg font-medium text-primary rounded md:bg-transparent md:text-primary md:p-0"
                  >Mobile phones</a
                >
              </li>
              <li>
                <a
                  href="#"
                  class="block py-2 px-3 text-lg font-medium text-primary rounded md:bg-transparent md:text-primary md:p-0"
                  >SIM only</a
                >
              </li>
              <li>
                <a
                  href="#"
                  class="block py-2 px-3 text-lg font-medium text-primary rounded md:bg-transparent md:text-primary md:p-0"
                  >About</a
                >
              </li>
            </ul>
          </div>
        </div>
      </nav>
  
      <!--Navbar Section End-->
      <!--Hero Section Start-->
      <!--Tv Remote Image-->
      <div class="block md:hidden">
        <img src="./images/tv_remote_header_landscape_min.webp" alt="" />
      </div>
      <!--Tv Remote End-->
      <section
        class="bg-[#001E70]"
        style="
          background-image: url('./images/header-banner-swoosh-light.svg');
          background-repeat: no-repeat;
          background-size: cover;
          background-position: center;
        "
      >
        <div class="flex flex-col justify-center items-center mx-auto p-8">
          <div class="flex items-center text-[#ffffff] text-lg opacity-50 mb-2">
            Home
            <img src="./images/chevron-right.svg" alt="" class="w-5 h-5" />
            Broadband
          </div>
          <h1
            class="text-white text-center text-5xl w-full md:max-w-3xl font-bold mb-8"
          >
            Broadband and TV deals
          </h1>
          <p class="text-white mb-8 max-w-3xl text-lg text-center">
            Bundle your broadband and TV and start saving money today. Compare
            packages and deals from just £30.99 per month. Enter your postcode to
            find the best deals in your area.
          </p>
  
          <form class="w-full max-w-md">
            <div class="flex w-full">
              <span
                class="inline-flex items-center px-5 py-3 rounded-s-lg text-sm text-white bg-[#FF006D]"
                dir="ltr"
              >
                <svg
                  class="w-6 h-6 text-white"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                  fill="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    d="M12 3l9 8.25V21a1 1 0 0 1-1 1h-6v-7H9v7H3a1 1 0 0 1-1-1V11.25L12 3z"
                  />
                </svg>
              </span>
  
              <input
                dir="rtl"
                type="text"
                id="website-admin"
                class="flex items-center text-gray-900 block flex-1 w-full text-sm p-3 rounded-s-lg focus:outline-none placeholder:text-lg placeholder:font-semibold placeholder:text-center"
                placeholder="Enter your Postcode"
              />
            </div>
          </form>
        </div>
      </section>
      <!--Hero Section End-->
      <!--Body Section Start-->
  
      <!--This box shows only in mobile view-->
      <div
        class="flex flex-col items-center justify-center bg-white block md:hidden py-6 px-4"
      >
        <h2 class="text-primary font-bold text-2xl mb-2">60 deals available</h2>
        <p class="text-primary mb-2">Can't find what you're looking for?</p>
        <div>
          <button
            class="rounded-full border border-primary px-6 py-2 font-bold text-base text-primary mr-2"
          >
            Filter my results
          </button>
          <button
            class="rounded-full border border-primary px-6 py-2 font-bold text-base text-primary"
          >
            Call us
          </button>
        </div>
      </div>
      <!--Box End-->

     <!--  start common section before side bar and content section -->
      <div class="w-full bg-blue-50">
        <div class="flex flex-col md:flex-row md:justify-between max-w-7xl mx-auto py-10"   >