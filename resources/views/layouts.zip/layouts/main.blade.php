<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8" />
    <title>Cables</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
      tailwind.config = {
        theme: {
          extend: {
            colors: {
              primary: "#000038",
              pink: "#FF006D",
              lightBlue: "#EDF2F5",
            },
            backgroundColor: {
              primary: "#000038",
              pink: "#FF006D",
              lightBlue: "#EDF2F5",
            },
          },
        },
      };
    </script>
    <style>
      .hover\:inner-shadow:hover {
        box-shadow: inset 0 0 18px rgba(0, 0, 0, 0.3);
      }
      .relative::after {
        content: "•"; /* Unicode character for a bullet point */
        color: black; /* Color of the dot */
        margin-left: 8px; /* Space between the text and the dot */
      }

      /* Hide the dot for the last item */
      .flex li:last-child::after {
        content: "";
      }
    </style>
  </head>
    {{-- @section('body') --}}
    @include('layouts.body')
    {{-- @show --}}
  
    <!-- Start Topbar Content here -->
    @include('layouts.topbar')
    <!-- End right side Content here -->


    <!-- Start right side Content here -->
    @include('layouts.sidebar')
    <!-- End right side Content here -->

    <!-- Start Body Content here -->
    @include('layouts.conent')
    <!-- End right side Content here -->

     <!-- Start Footer Content here -->
     @include('layouts.footer')
     <!-- End right side Content here -->
 
