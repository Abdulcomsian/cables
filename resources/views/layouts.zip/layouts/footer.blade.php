<section
class="bg-[#001E70] py-10"
style="
  background-image: url('./images/header-banner-swoosh-light.svg');
  background-repeat: no-repeat;
  background-size: cover;
  background-position: center;
"
>
<div
  class="flex flex-col justify-center items-center px-4 mx-auto max-w-7xl"
>
  <h2 class="text-white text-center text-2xl md:text-3xl font-bold mb-4">
    Need help choosing a deal? Call us on
  </h2>
  <p class="text-white text-2xl md:text-3xl font-bold mb-4">
    0333 210 1160
  </p>
  <p class="text-white text-lg text-center">
    Our experts are available from 8am-8pm Monday to Sunday
  </p>
</div>
</section>

<!-- End body tag here -->
</body>
</html>
